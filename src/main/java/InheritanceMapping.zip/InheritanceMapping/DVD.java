package InheritanceMapping;
import jakarta.persistence.*;

@Entity
@DiscriminatorValue("DVD")
public class DVD extends Item {
    @Column(name = "director", length = 100)
    private String director;
    
    @Column(name = "region_code", length = 10)
    private String regionCode;

    // Getters and setters
    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public String getRegionCode() {
        return regionCode;
    }

    public void setRegionCode(String regionCode) {
        this.regionCode = regionCode;
    }
}