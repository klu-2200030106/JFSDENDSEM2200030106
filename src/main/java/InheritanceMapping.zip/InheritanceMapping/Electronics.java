package InheritanceMapping;
import jakarta.persistence.*;

@Entity
@Table(name = "ELECTRONICS")
@PrimaryKeyJoinColumn(name = "productId")
public class Electronics extends Product {
    @Column(name = "warranty", length = 50)
    private String warranty;
    
    @Column(name = "brand", length = 50)
    private String brand;

    // Getters and setters
    public String getWarranty() {
        return warranty;
    }

    public void setWarranty(String warranty) {
        this.warranty = warranty;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }
}
