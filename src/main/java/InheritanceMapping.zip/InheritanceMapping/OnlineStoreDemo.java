package InheritanceMapping;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class OnlineStoreDemo {
    public static void main(String[] args) {
        Configuration cfg = new Configuration();
        cfg.configure("hibernate.cfg.xml");
        cfg.addAnnotatedClass(Product.class);
        cfg.addAnnotatedClass(Electronics.class);
        cfg.addAnnotatedClass(Clothing.class);

        SessionFactory sf = cfg.buildSessionFactory();
        Session session = sf.openSession();

        Transaction t = session.beginTransaction();

        // Create and save an Electronics product
        Electronics laptop = new Electronics();
        laptop.setName("Gaming Laptop");
        laptop.setWarranty("2 years");
        laptop.setBrand("Asus");

        // Create and save a Clothing product
        Clothing shirt = new Clothing();
        shirt.setName("Cotton T-Shirt");
        shirt.setSize("M");
        shirt.setMaterial("100% Cotton");

        session.persist(laptop);
        session.persist(shirt);

        t.commit();
        System.out.println("Products saved successfully!");

        session.close();
        sf.close();
    }
}