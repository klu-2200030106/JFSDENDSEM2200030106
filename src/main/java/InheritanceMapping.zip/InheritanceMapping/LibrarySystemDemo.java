package InheritanceMapping;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class LibrarySystemDemo {
    public static void main(String[] args) {
        Configuration cfg = new Configuration();
        cfg.configure("hibernate.cfg.xml");
        cfg.addAnnotatedClass(Item.class);
        cfg.addAnnotatedClass(Book.class);
        cfg.addAnnotatedClass(DVD.class);

        SessionFactory sf = cfg.buildSessionFactory();
        Session session = sf.openSession();

        Transaction t = session.beginTransaction();

        // Create and save a Book
        Book book = new Book();
        book.setTitle("The Great Gatsby");
        book.setAuthor("F. Scott Fitzgerald");
        book.setIsbn("9780743273565");

        // Create and save a DVD
        DVD dvd = new DVD();
        dvd.setTitle("Inception");
        dvd.setDirector("Christopher Nolan");
        dvd.setRegionCode("R1");

        session.persist(book);
        session.persist(dvd);

        t.commit();
        System.out.println("Items saved successfully!");

        session.close();
        sf.close();
    }
}