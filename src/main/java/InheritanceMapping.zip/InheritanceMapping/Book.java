package InheritanceMapping;


import jakarta.persistence.*;

@Entity
@DiscriminatorValue("BOOK")
public class Book extends Item {
    @Column(name = "author", length = 100)
    private String author;
    
    @Column(name = "isbn", length = 20)
    private String isbn;

    // Getters and setters
    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }
}