package InheritanceMapping;
import jakarta.persistence.*;

@Entity
@Table(name = "CLOTHING")
@PrimaryKeyJoinColumn(name = "productId")
public class Clothing extends Product {
    @Column(name = "size", length = 20)
    private String size;
    
    @Column(name = "material", length = 50)
    private String material;

    // Getters and setters
    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }
}